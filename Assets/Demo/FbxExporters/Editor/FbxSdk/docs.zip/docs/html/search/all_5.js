var searchData=
[
  ['inoutreferencemanager',['InOutReferenceManager',['../struct_in_out_reference_manager.html',1,'']]]
];
